from torch.utils.data import Dataset
from PIL import Image
import numpy as np
import os
import pickle
from torch.utils.data import DataLoader
import torchvision.transforms as tfs
from .distributed_dataset import distributed_dataset

import scipy.io as sio
from glob import glob


class Oxford_cat_dog(Dataset):
    def __init__(self, root=r'C:\Users\mahfu\Desktop\Chen course project\Oxford IIIT pet dataset\images\repr images2\New folder\resized\combined_sorted', train=True, transform=None):
        
        self.root = root
        self.transform = transform
        
        labels_file_loc = os.path.join(root, 'labels.mat')
        labels = sio.loadmat(labels_file_loc)
        
        self.img_train = sorted(glob(root+'/train/*.jpg'))
        self.img_test = sorted(glob(root+'/test/*.jpg'))
        
        self.labels_train = labels['labels_train']
        self.labels_test = labels['labels_test']
        
        # print(self.img_train[0])
        # print(self.img_test[0])
               
        
        if train:
            self.data = self.img_train
            self.targets = self.labels_train
        else:
            self.data = self.img_test
            self.targets = self.labels_test

    def __getitem__(self, item):
        data, targets = np.array(Image.open(self.data[item])), self.targets[item][0]
                
        # data = data.astype(np.float32)
        # print(data.shape, data.dtype)
        if self.transform is not None:
            data = self.transform(data)
        return data, targets-np.ones_like(targets)

    def __len__(self):
        return len(self.data)


def oxford_cat_dog(rank, split=None, ### Need to prepare the data split
                  batch_size=None, transforms=None
                  , test_batch_size=64, is_distribute=True, seed=777, path=r'C:\Users\mahfu\Desktop\Chen course project\Oxford IIIT pet dataset\images\repr images2\New folder\resized\combined_sorted', **kwargs):
    if transforms is None:
        transforms = tfs.Compose([
            tfs.ToTensor(),
        ])
    if batch_size is None:
        batch_size = 1
    if split is None:
        split = [1.0]
    if not os.path.exists(path):
        os.mkdir(path)
    train_set = Oxford_cat_dog(path, True, transforms)
    test_set = Oxford_cat_dog(path, False, transforms)
    if is_distribute:
        train_set = distributed_dataset(train_set, split, rank, seed=seed)
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, drop_last=True)
    test_loader = DataLoader(test_set, batch_size=test_batch_size, drop_last=True)
    return train_loader, test_loader, (3, 32, 32), 2

