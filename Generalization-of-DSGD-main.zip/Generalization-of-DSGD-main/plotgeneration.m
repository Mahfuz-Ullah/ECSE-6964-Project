clear all
close all

% Define the epochs correctly to match the number of data points
epochs = 3:1:20;  % Corrected to match the number of epochs for which you provided data

% Data for All Connected Topology
training_loss_ac = [0.370444, 0.272482, 0.198731, 0.146214, 0.095367, 0.061743, 0.045375, 0.025338, 0.016601, 0.011668, 0.008004, 0.005974, 0.003666, 0.002269, 0.001495, 0.001398, 0.001295, 0.001198];
training_accuracy_ac = [0.832129, 0.892745, 0.927136, 0.953832, 0.975817, 0.989165, 0.992776, 0.99733, 0.998587, 0.999668, 0.999843, 0.999986, 1, 1, 1, 1, 1, 1];
testing_accuracy_ac = [0.799479, 0.841146, 0.863281, 0.85026, 0.863281, 0.876302, 0.867188, 0.861979, 0.865885, 0.868055, 0.86849, 0.876302, 0.875, 0.877604, 0.872396, 0.875, 0.874302, 0.875];

% Data for Ring Topology
training_loss_ring = [0.361716, 0.275799, 0.210673, 0.163695, 0.106629, 0.070754, 0.048407, 0.026053, 0.017105, 0.012571, 0.008238, 0.005458, 0.003782, 0.002295, 0.001429, 0.001185, 0.001086, 0.000995];
training_accuracy_ring = [0.836997, 0.893373, 0.919192, 0.944095, 0.973147, 0.986338, 0.992148, 0.995917, 0.997487, 0.998908, 0.999215, 0.999685, 1, 1, 1, 1, 1, 1];
testing_accuracy_ring = [0.8125, 0.850273, 0.885073, 0.869792, 0.869792, 0.886458, 0.864583, 0.869792, 0.870192, 0.876302, 0.872396, 0.873958, 0.876302, 0.875, 0.873958, 0.877604, 0.876, 0.8765];

% Data for Exponential Topology
training_loss_exp = [0.369594, 0.272686, 0.199339, 0.148569, 0.097029, 0.064213, 0.044437, 0.026503, 0.017101, 0.012515, 0.008241, 0.005458, 0.003782, 0.002296, 0.001428, 0.001185, 0.001082, 0.000985];
training_accuracy_exp = [0.835113, 0.894001, 0.928235, 0.952575, 0.974246, 0.987437, 0.99309, 0.997487, 0.999058, 0.999508, 0.999658, 0.999686, 0.999686, 1, 1, 1, 1, 1];
testing_accuracy_exp = [0.800781, 0.842448, 0.860677, 0.860677, 0.869792, 0.88796, 0.88796, 0.869792, 0.870192, 0.876302, 0.873958, 0.876302, 0.876302, 0.875, 0.875, 0.877604, 0.877, 0.8775];

% Plot Training and Testing Loss
figure;
plot(epochs, training_loss_ac, 'b-o', 'LineWidth', 2, 'DisplayName', 'All Connected - Training');
hold on;
plot(epochs, training_loss_ring, 'r-*', 'LineWidth', 2, 'DisplayName', 'Ring - Training');
plot(epochs, training_loss_exp, 'g-x', 'LineWidth', 2, 'DisplayName', 'Exponential - Training');
xlabel('Epoch');
ylabel('Training Loss');
title('Training Loss Across Topologies');
legend show;
grid on;

% Plot Training and Testing Accuracy
figure;
plot(epochs, training_accuracy_ac, 'b-o', 'LineWidth', 2, 'DisplayName', 'All Connected - Training');
hold on;
plot(epochs, training_accuracy_ring, 'r-*', 'LineWidth', 2, 'DisplayName', 'Ring - Training');
plot(epochs, training_accuracy_exp, 'g-x', 'LineWidth', 2, 'DisplayName', 'Exponential - Training');
xlabel('Epoch');
ylabel('Training Accuracy (%)');
title('Training Accuracy Across Topologies');
legend show;
grid on;
